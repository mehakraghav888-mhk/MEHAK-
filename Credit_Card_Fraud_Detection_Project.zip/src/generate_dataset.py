import numpy as np
import pandas as pd
from pathlib import Path

rng = np.random.default_rng(42)
n = 8000

amount = np.round(rng.lognormal(mean=3.2, sigma=1.0, size=n), 2)
amount = np.clip(amount, 1, 5000)
hour = rng.integers(0, 24, n)
distance = np.round(rng.gamma(shape=2.0, scale=20.0, size=n), 2)
velocity = np.round(rng.gamma(shape=2.0, scale=1.5, size=n), 2)
device_change = rng.binomial(1, 0.08, n)
international = rng.binomial(1, 0.12, n)
failed_attempts = rng.poisson(0.25, n)
merchant_risk = np.round(rng.beta(2, 5, n), 3)

# Synthetic fraud signal for demonstration.
score = (
    -5.2
    + 0.00055 * amount
    + 0.045 * distance
    + 0.70 * velocity
    + 1.25 * device_change
    + 1.40 * international
    + 0.55 * failed_attempts
    + 2.20 * merchant_risk
    + 0.65 * ((hour <= 5) | (hour >= 23))
)
prob = 1 / (1 + np.exp(-score))
fraud = rng.binomial(1, np.clip(prob, 0, 0.98))

df = pd.DataFrame({
    "amount": amount,
    "hour": hour,
    "distance_km": distance,
    "transactions_last_hour": velocity,
    "device_change": device_change,
    "international": international,
    "failed_attempts": failed_attempts,
    "merchant_risk": merchant_risk,
    "is_fraud": fraud
})

# Keep a reasonable fraud rate for an educational demo.
df.to_csv(Path(__file__).resolve().parents[1] / "data" / "transactions.csv", index=False)
print(f"Created {len(df)} transactions.")
print(df["is_fraud"].value_counts(normalize=True).rename("proportion"))
